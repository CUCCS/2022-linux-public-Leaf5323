#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main(){
	int a,b,n;
	srand(time(NULL));
	a=rand()%100+1;
	n=0;
	while(a!=b){
		scanf("%d",&b);
		if(a>b){
			n++;
			printf("Wrong!Too low!\n");
		}
		else if(a<b){
			n++;
			printf("Wrong!Too high!\n");
		}
	}
	if(a==b){
		n++;
		printf("Right!\nYou guess %d times\nThe game is over!",n);
	}
}


